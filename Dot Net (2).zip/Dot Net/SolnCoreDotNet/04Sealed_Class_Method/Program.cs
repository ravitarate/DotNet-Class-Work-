﻿namespace _04Sealed_Class_Method
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AdCmath AD = new Math();
            Console.WriteLine( AD.sqaure(5));
            AD.Dispaly();
         
        }
    }

    public sealed class CMath
    {
        public int add(int x, int y)
        {
            return x + y;
        }
        public int sub(int x, int y)
        {
            return x - y;
        }
    }


    public class AdCmath
    {
        public void Dispaly()
        {
            CMath objC = new CMath();
            Console.WriteLine(objC.add(1, 2));
            Console.WriteLine(objC.sub(2, 3)); 
        }
        public virtual int sqaure(int x)
        {
            return x * x;
        }

        public virtual int Div(int m , int n)
        {
            return m / n;
        }
    }

    public class Math : AdCmath
    {

        public void Mul(int x , int y)
        {
            Console.WriteLine(x * y);
        }

        public override int sqaure(int x)
        {
            return x*x+1999;
        }
        public sealed override int Div(int m, int n)
        {
            return m / n+54;
        }

    }


}
