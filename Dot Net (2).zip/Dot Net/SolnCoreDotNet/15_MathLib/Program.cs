﻿
using _14_Math_Lib;

namespace _15_MathLib
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Operations op = new Operations();

            op.Add(2, 32);

            AMath math = new AMath();

            math.WrapMul(38, 4);
            math.Wrapmod(38, 2);

        }
    }

    public class AMath: Operations
    {
        public void WrapMul(int x,int y)
        {
            mul(x,y);
        }

        public void Wrapmod(int x, int y)
        {
            mod(x, y);
        }
    }
}
