﻿namespace _23_Generic_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Emp emp = new Emp();
            emp.Id = 1;
            emp.Name = "ABC";
            emp.Add = "XYZ";

            Emp emp1 = new Emp();
            emp.Id = 2;
            emp.Name = "Ram";
            emp.Add = "pune";

            Emp emp2 = new Emp();
            emp.Id = 3;
            emp.Name = "Sham";
            emp.Add = "Nashik";

            List<Emp> empList = new List<Emp>();
            empList.Add(emp1);
            empList.Add(emp2);
            empList.Add(emp);

            foreach (Emp e in empList)
            {
                e.Display();
            }
        }
    }




    public class Emp
    {
        private int _id;
        private string _name;
        private string _add;

        public string Add
        {
            get { return _add; }
            set { _add = value; }
        }


        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }


        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public void Display()
        {
            Console.WriteLine($"Id :{Id}, Name :{Name}, Add :{Add}");
        }




    }


}
