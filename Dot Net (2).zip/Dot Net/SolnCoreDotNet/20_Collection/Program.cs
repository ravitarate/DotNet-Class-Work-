﻿using System.Collections;

namespace _20_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Array
            //int[] arr = new int[5];
            //arr[0] = 100;
            //arr[1] = 200;
            //arr[2] = 300;
            //arr[3] = 400;


            //for (int i = 0; i < arr.Length; i++)
            //{
            //    Console.WriteLine(arr[i]);
            //} 
            #endregion

            Emp emp = new Emp();

            emp.Id = 1;
            emp.Name = "Ram";
            emp.Address = "Pune";

            Emp emp1 = new Emp();

            emp1.Id = 2;
            emp1.Name = " ramesh";
            emp1.Address = "nagar";

            Emp emp2 = new Emp();

            emp2.Id = 3;
            emp2.Name = "Snehal";
            emp2.Address = "Pune";

            #region ArrayOf Employee Object
            //Emp[] empArr = new Emp[3];

            //empArr[0] = emp;
            //empArr[1] = emp1;
            //empArr[2] = emp2;


            //for (int i = 0; i < empArr.Length; i++)
            //{

            //    Console.WriteLine(empArr[i].Id);

            //    Emp empref = empArr[i];
            //    Console.WriteLine($" id {empref.Id} , {empref.Name} , address {empref.Address} ");
            //} 
            #endregion


            Book book1 = new Book();

            book1.Auth = " V.S.Khandekar";
            book1.BookName = "Yayati";




            #region  array of object and Conversion 
            //object[] obj = new object[5];

            //obj[0] = emp1;
            //obj[1] = emp2;
            //obj[2] = emp;
            //obj[3] = book1;
            //obj[4] = 100; // boxing 

            //for (int i = 0; i< obj.Length; i++)
            //{
            //    if(obj[i] is int)
            //    {
            //        int num = Convert.ToInt32(obj[i]);  // unboxing
            //        Console.WriteLine(num);
            //    }

            //    if(obj[i] is Emp)
            //    {
            //        Emp eref = obj[i] as Emp;  // typeCasting  
            //        Console.WriteLine($"Id = {eref.Id}, Name = {eref.Name}, Address = {eref.Address}");
            //    }

            //    if (obj[i] is Book)
            //    {
            //        Book bref = obj[i] as Book;
            //        Console.WriteLine($"Book Name = {bref.BookName}, Author = {bref.Auth}");
            //    }
            //} 
            #endregion



            #region ArrayList 

            //ArrayList arr = new ArrayList();

            //arr.Add(100);
            //arr.Add(200);
            //arr.Add(emp);
            //arr.Add(book1);
            //arr.Add(emp1);

            //foreach (var item in arr)
            //{
            //    if (item is int)
            //    {
            //        int num = Convert.ToInt32(item);
            //        Console.WriteLine(num);
            //    }
            //    if(item is Emp)
            //    {

            //        Emp e = item as Emp;
            //        Console.WriteLine($"{e.Id},{e.Name},{e.Address}");

            //    }
            //    if(item is Book)
            //    {
            //        Book b = item as Book;
            //        Console.WriteLine($"{b.Auth},{b.BookName}");
            //    }


            //} 
            #endregion



            #region Hashtable
            //Hashtable ht = new Hashtable();

            //ht.Add(1, "Ronaldo");
            //ht.Add(2, "Neyamr");
            //ht.Add(3, "Khala");
            //ht.Add(4, emp);
            //ht.Add(5, book1);
            //ht.Add(6, 5000);



            //foreach (var o in ht.Keys)
            //{
            //    if(ht[o] is int)
            //    {
            //        int num = Convert.ToInt32(ht[o]);
            //        Console.WriteLine(num);
            //    }

            //    if(ht[o] is string)
            //    {
            //        Console.WriteLine(ht[o].ToString());    
            //    }

            //    if(ht[o] is Emp)
            //    {
            //          Emp eref = ht[o] as Emp;
            //        Console.WriteLine(eref.Name);

            //    }
            //    if(ht[o] is Book)
            //    {
            //        Book bref = ht[o] as Book;
            //        Console.WriteLine(bref.BookName);
            //    }

            //} 
            #endregion



            #region Stack
            //Stack st = new Stack();

            //st.Push(100);
            //st.Push(200);
            //st.Push(692);
            //st.Push(emp);
            //st.Push(emp1);
            //st.Pop();



            //foreach (Object A in st)
            //{
            //    if (A is int)
            //    {
            //        int num = Convert.ToInt32(A);
            //        Console.WriteLine($"Integer value is {num}");
            //    }

            //    if (A is Emp)
            //    {
            //        Emp e = A as Emp;
            //        Console.WriteLine($" id is {e.Id},Name is{e.Name},Address{e.Address}");
            //    }
            //} 
            #endregion


            #region Queue

            //Queue queue = new Queue();

            //queue.Enqueue(book1);
            //queue.Enqueue(emp1);
            //queue.Enqueue(100);
            //queue.Enqueue(200);
            //queue.Enqueue(300);
            //queue.Dequeue();

            //foreach (var item in queue)
            //{

            //    if (item is Emp)
            //    {
            //        Emp e = item as Emp;
            //        Console.WriteLine($"ID{e.Id} , Name{e.Name}");
            //    }
            //    if (item is Book)
            //    {
            //        Book b = item as Book;
            //        Console.WriteLine($"Author{b.Auth}, NameBook{b.BookName}");
            //    }
            //    if (item is int)
            //    {

            //        int num = Convert.ToInt32(item);
            //        Console.WriteLine(num);
            //    }

            //} 
            #endregion

            var data2 = Display(1,"Jane Doe", "456 Oak Avenue");
            Console.WriteLine($"id = {data2.Id}, Name = {data2.name}, Address = {data2.address}"); 

        }

        public static (int Id, string name, string address) Display(int id, string nm, string add)
            {
                //object[] arr = new object[3];
                //arr[0] = id;
                //arr[1] = nm;
                //arr[2] = add;
                //ArrayList arr = new ArrayList();
                // arr.Add( id);
                // arr.Add( nm);
                // arr.Add( add);
                int Id = id;
                string name = nm;
                string address = add;
                return (Id, name, address);
            }
    }

 








    public class Emp

        
    {
        private String Ename;
        private int id;
        private String Add;

        public string Address
        {
            get { return Add; }
            set { Add = value; }
        }



        public int Id
        {
            get { return id; }
            set { id = value; }
        }


        public string Name         
        {
            get { return Ename; }
            set { Ename = value; }
        }

        

    }

    public class Book
    {
        private string Author;
        private string NameOfBook;


       

        public  string Auth
        {
            get { return Author; }
            set { Author = value; }
        }



        public string BookName
        {
            get { return NameOfBook; }
            set { NameOfBook = value; }
        }




    }

}
