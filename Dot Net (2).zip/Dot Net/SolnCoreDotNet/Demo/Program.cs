﻿// See https://aka.ms/new-console-template for more information


Emp e = new Emp(1, "ram", 2323);

e.display();

public class Emp
{
    private int _id { get; set; }
    private string _name { get; set; }
    private int _sal { get; set; }
    
    public Emp(int id, string name, int sal)
    {
        _id = id;
        _name = name;
        _sal = sal;
    }

    public void display()
    {
        Console.WriteLine($"Id: {_id}, Name:{_name}, Sal:{_sal}");
    }
}
