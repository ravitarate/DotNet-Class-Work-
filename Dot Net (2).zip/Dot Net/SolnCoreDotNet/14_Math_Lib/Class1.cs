﻿namespace _14_Math_Lib
{
    public class Operations
    {

        public void Add(int x, int y)
        {
            Console.WriteLine(x + y);
        }

        private void sub(int x, int y)
        {
            Console.WriteLine(x - y);
        }

        protected void mul(int x, int y)
        {
            Console.WriteLine(x * y);
        }

        internal void div(int x, int y)
        {
            Console.WriteLine(x / y);
        }

        protected internal void mod(int x, int y)
        {
            Console.WriteLine(x % y);
        }

    }

    public class AdvOperations : Operations
    {
        public void Demo()
        {
            Add(1, 2);
            mul(1, 2);
            div(10, 2);
            mod(22, 2);


        }
    }
}


