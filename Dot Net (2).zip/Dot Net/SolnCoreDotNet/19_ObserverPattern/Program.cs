﻿namespace _19_ObserverPattern
{
    public delegate void NotifyDelegate(string message);
    internal class Program
    {
        static void Main(string[] args)
        {
            Publisher publisher = new Publisher();
            Subscriber subscriber = new Subscriber();

            
            publisher.Notify += subscriber.MethodA;
            publisher.Notify += subscriber.MethodB;

           
            publisher.TriggerEvent();

            Console.WriteLine("---------------");
            
            publisher.Notify -= subscriber.MethodB;

            publisher.TriggerEvent();
        }
    }
    public class Subscriber 
    {
        public void MethodA(string message)
        {
            Console.WriteLine($"MethodA received : {message}");
        }
        public void MethodB(string message)
        {
            Console.WriteLine($"MethodB received : {message}");
        }
    }
    public class Publisher
    {
        public event NotifyDelegate Notify;

        public void TriggerEvent()
        {
            Notify?.Invoke("Event has been triggered....");
        }
    }
}
