﻿using System.Collections;

namespace _22_Generic_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int[] numbers = new int[3];

            numbers[0] = 11;
            numbers[1] = 12;
            numbers[2] = 13;

            Demo demo = new Demo();
            demo.Add(numbers);


            string nm = "pablo Escobar";
            string add = "Columbia";
            string str = string.Format("Name = {0} , Address = {1}", nm, add);
            Console.WriteLine(str);

            ArrayList arr = demo.playerNames(1112, "shanta bai", "yemuna bai", "yedu bai", "savkar");
            foreach(var name in arr)
            {
                Console.WriteLine(name);
            }
        }
    }


    public class Demo
    {
        public void Add(int[] arr)
        {
            int addResult = 0;
            for (int i = 0; i < arr.Length; i++)
            {

                addResult += arr[i];
            }
            Console.WriteLine("Addresult  = {0}", addResult);
        }

        public ArrayList playerNames(int x, params string[] names)
        {
            Console.WriteLine($"x : {x}");
            ArrayList arrayList = new ArrayList();
            foreach (var name in names)
            {
                arrayList.Add(name);

            }
            return arrayList;
        }
    }

   
}
