﻿namespace _08_Interface4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Enter a choice 1.SQl 2.NoSQL 3. Oracle");
                int dbchoice = Convert.ToInt32(Console.ReadLine());

                DataBaseFactory dbfactory = new DataBaseFactory();

                DataBase db = dbfactory.MyFactory(dbchoice);

                if (db != null)
                {

                    Console.WriteLine("select 1.insert  2.update  3.delete6");
                    int ch = Convert.ToInt32(Console.ReadLine());

                    switch (ch)
                    {
                        case 1:
                            db.insert();
                            break;

                        case 2:
                            db.update();
                            break;

                        case 3:
                            db.delete();
                            break;

                        default:
                            Console.WriteLine("Invalid choice");
                            break;
                    }
                }
                Console.WriteLine("Do you want to continue? y/ n");
                string chr = Console.ReadLine().ToLower();
                if (chr == "n")
                {
                    break;
                }
            }

        }
    }


        public interface DataBase
        {
            public void insert();

            public void update();

            public void delete();
        }


        public class DataBaseFactory
        {
            public DataBase MyFactory(int dbchoice)
            {

                DataBase db = null;
                switch (dbchoice)
                {
                    case 1:
                        db = new SQl();
                        break;

                    case 2:
                        db = new NoSQL();
                        break;

                    case 3:
                        db = new Oracle();
                        break;

                    default:
                        Console.WriteLine("Invalid choice");
                        break;

                }

                return db;
            }


        }

        public class SQl : DataBase
        {

            public void insert()
            {
                Console.WriteLine(" Add Data ");
            }
            public void update()
            {
                Console.WriteLine("modify data");
            }
            public void delete()
            {
                Console.WriteLine("delete data");
            }

        }

        public class NoSQL : DataBase
        {

            public void insert()
            {
                Console.WriteLine(" Add Data ");
            }
            public void update()
            {
                Console.WriteLine("modify data");
            }
            public void delete()
            {
                Console.WriteLine("delete data");
            }

        }

        public class Oracle : DataBase
        {

            public void insert()
            {
                Console.WriteLine(" Add Data ");
            }
            public void update()
            {
                Console.WriteLine("modify data");
            }
            public void delete()
            {
                Console.WriteLine("delete data");
            }

        }

}
