﻿namespace _17_MultiCast_delegate
{
    public delegate void Mydelegate();

    internal class Program
    {

        static void Main(string[] args)   
        {
            AnnualFunction af = new AnnualFunction();

            Mydelegate md = new Mydelegate(af.WelCome);
            md += af.Speech;
            md += af.CelebritySpeech;
            md += af.TalentShow;
            md += af.DinnerParty;
            md += af.GoodBye;

            Console.WriteLine("Is it a closure ?");
            bool isClosure = Convert.ToBoolean(Console.ReadLine());
            if (isClosure)
            {
                md += af.PackUp; 
            }
            else
            {
                md -= af.PackUp; 
            }

            md += af.GoodNight;

            md();

        }
    }

    public class AnnualFunction
    {
        public void WelCome()
        {
            Console.WriteLine("Wel-come everyone for our annual event function ....!!!!");
        }
        public void Speech()
        {
            Console.WriteLine("In-house Guest Speech : Blah blah blah....!!!!");
        }
        public void CelebritySpeech()
        {
            Console.WriteLine("Celebrity Guest Speech : Thank you everyone for having me tonight!! and blah blah blah....!!!!");
        }
        public void TalentShow()
        {
            Console.WriteLine("Next is  : Lets enjoy our performances | Dance | Sining | Drama!!!!");
        }
        public void DinnerParty()
        {
            Console.WriteLine("Next is  : Lets enjoy our dinner party!!!!");
        }
        public void GoodBye()
        {
            Console.WriteLine("Thank you everyone for enjoying and Good - night!!!!");
        }
        public void PackUp()
        {
            Console.WriteLine("Thank you everyone .. Lets Pack-up ");
        }
        public void GoodNight()
        {
            Console.WriteLine("Good - night!!!!");
        }
    }
}
