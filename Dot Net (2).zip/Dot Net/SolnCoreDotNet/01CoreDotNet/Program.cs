﻿namespace _01CoreDotNet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region inputoutput
            //Console.WriteLine("Hello, World!");
            //Console.WriteLine(Console.ReadLine());
            //Console.Read();
            //Console.ReadKey(); 

            //Console.WriteLine(" Enter first no ");

            //int num1Input = Convert.ToInt32(Console.ReadLine());


            //Console.WriteLine("Enter Secoud number no ");
            //int num2input = Convert.ToInt32(Console.ReadLine());

            //int result = num1Input + num2input;

            //Console.WriteLine(result);
            #endregion

            #region TypeCast and Boxing , Unboxing
            //int a = 10;
            //double b;
            //b = a;

            //Console.WriteLine(b);
            //String str = " hello ";
            //object obj = null;
            //obj = str;
            //Console.WriteLine(obj);


            //int num = 100;
            //String str1 = " hello ";
            //str1 = num.ToString();    // boxing value type to reference type 
            //int m1 = Convert.ToInt32(str1);// unboxing refrence type to value type
            //Console.WriteLine(str1);
            //Console.WriteLine(m1);

            //double d = 9656.695;
            //int n = Convert.ToInt32(d);  // value type to value type (typecast)
            //Console.WriteLine(n); 
            #endregion

            #region Conditions,Loops
            #region Conditions
            // Console.WriteLine("Enter the number");
            //int num= Convert.ToInt32(Console.ReadLine());

            // if (num % 2 == 0){

            //     Console.WriteLine(" Number is Even");
            // }
            // else
            // {
            //     Console.WriteLine("Number is odd ");
            // }


            //Console.WriteLine("Enter the number");
            //int n = Convert.ToInt32(Console.ReadLine());

            //if(n >= 18 && n < 100)
            //{
            //    Console.WriteLine(" Candidate is eligible for voting ");
            //}else if (n < 18)
            //{
            //    Console.WriteLine(" you are not eligible for voting ");
            //}else 
            //{
            //    Console.WriteLine("you also not eligible for voting  ");
            //}  
            #endregion

            #region Loops
            //int x = 1;
            //while (x <= 10)
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}


            //int x = 1;
            //do {


            //    Console.WriteLine(x);
            //    x++;


            //} while(x<=20);

            //for(int y=0; y < 10; y++)
            //{
            //    Console.WriteLine(y);   
            //} 



            #endregion




            #endregion





        }
    }

}
