﻿using System.Security.Cryptography.X509Certificates;

namespace _16_Delegate_1
{

    public delegate void printDelegate();
    public delegate void printDelegate1(string s);

    internal class Program
    {
        static void Main(string[] args)
        {
            printDelegate pd = new printDelegate(Hello);
            pd.Invoke();

            printDelegate1 pd1 = new printDelegate1(Hello);
            pd1("Ram");

        }

        public static void Hello()
        {
            Console.WriteLine("hello");
        }

        public static void Hello(string s)
        {
            Console.WriteLine($"hwllo {s}");
        }
    }
}
