﻿namespace _13_Class_Proporties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(1,"Sham","admin",324234);
            //emp.ID = 1;
            //emp.Name = "Ram";
            //emp.Desc = "HR";
            //emp.Sal = 43243;
            //Console.WriteLine(emp.ID);
            //Console.WriteLine(emp.Name);
            //Console.WriteLine(emp.Desc);
            //Console.WriteLine(emp.Sal);

            emp.display();
        }
    }

    public class Employee
    {
        private int id;
        private string name;
        private string desc;
        private double sal;

        public Employee(int id, string name, string desc, double sal)
        {
            this.id = id;
            this.name = name;
            this.desc = desc;
            this.sal = sal;
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Desc
        {
            get{ return desc; }
            set { desc = value; }
        }

        public double Sal
        {
            get { return sal; }
            set { sal = value; }
        }

        public void display()
        {
            Console.WriteLine("id :" + id + " Name :" + name + " Desc:" + desc + " Sal :" + sal);
        }
    }
}
