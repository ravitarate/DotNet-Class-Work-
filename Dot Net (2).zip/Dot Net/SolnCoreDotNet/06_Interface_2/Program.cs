﻿namespace _06_Interface_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter choice");
            int ch = Convert.ToInt32(Console.ReadLine());

            if (ch == 1)
            {
                Math1 m1 = new Solution();
                Console.WriteLine($"Sub = {m1.sub(3, 6)}");
                Console.WriteLine($"Add = {m1.add(3, 9)}");
            }
            else if (ch == 2)
            {
                Math2 m2 = new Solution();
                Console.WriteLine($"Div = {m2.div(24, 6)}");
                Console.WriteLine($"Mul = {m2.mul(24, 9)}");
            }
            else if(ch == 3){
                Math3 m3 = new Solution();
                Console.WriteLine($"Sub = {m3.sub(3, 6)}");
                Console.WriteLine($"Add = {m3.add(3, 9)}");
                Console.WriteLine($"Div = {m3.div(24, 6)}");
                Console.WriteLine($"Mul = {m3.mul(24, 9)}");
            }
            else
            {
                Console.WriteLine("Wrong Choice");
                return;
            }
        }
    }

    public interface Math1
    {
        public int add(int x, int y);
        public int sub(int n, int m);
    }

    public interface Math2
    {
        public int mul(int x, int y);  
        public int div(int x, int y);
    }

    public interface Math3
    {
        public int add(int x, int y);
        public int sub(int n, int m);
        public int mul(int x, int y);
        public int div(int x, int y);
    }

    public class Solution : Math1, Math2, Math3
    {
        public int add(int x, int y)
        {
            return x + y;
        }

        public int div(int x, int y)
        {
            return x / y;
        }

        public int mul(int x, int y)
        {
            return x * y;
        }

        public int sub(int n, int m)
        {
            return n - m;
        }
    }
}
