﻿namespace _05_Interface_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("choose  Employee type 1. Salaraied Employee / 2. Contract Employee ");
            int ch =Convert.ToInt32(Console.ReadLine());   

            Employee e = null;
            if(ch ==1)
            {
                e = new Salaried(); 
            }
            else if(ch == 2){
                e = new Contract();
            }
            else
            {
                Console.WriteLine(" Invalid Choice ");
                return;
            }
            Console.WriteLine($"Salary  is {e.salary(50000)}");
        }
    }

    public interface Employee
    {
        public double salary(double x);   
    }

    public class Salaried:Employee
    {
        public double salary(double x)
        {
            return x; 
        }   

    }

    public class Contract : Employee
    {
        public double salary(double x)
        {
            return x + 500;
        }
    }
}
