﻿namespace _09_Abstract
{
    internal class Program
    {
        static void Main(string[] args)
        {
           

            Console.WriteLine("Enter your report choice: 1. PDF, 2. DocX 3. Doc1h");
            int reportChoice = Convert.ToInt32(Console.ReadLine());
            ReportFactory factory = new ReportFactory();
            Report report = factory.GetSomeReport(reportChoice);
            report.GetReport();
        }
    }
    public abstract class Report
    {
        protected abstract void Parse();
        protected abstract void Validate();
        protected abstract void Save();

        public virtual void GetReport()
        {
            Parse();
            Validate();
            Save();

            Console.WriteLine("Report Generated Successfully!");
        }
    }

    public abstract class Report1 : Report
    {
        
        protected abstract void ReValidate();

        public override void GetReport()
        {
            Parse();
            Validate();
            ReValidate();
            Save();

            Console.WriteLine("Report Generated Successfully!");
        }
    }


    public class ReportFactory
    {
        public Report GetSomeReport(int choice)
        {
            Report report = null;
            switch (choice)
            {
                case 1:
                    report = new PDF();
                    break;
                case 2:
                    report = new DocX();
                    break;
                case 3:
                    report = new Doc1();
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
            return report;
        }
    }
    public class PDF : Report
    {
        protected override void Parse()
        {
            Console.WriteLine("PDF Parsed..");
        }

        protected override void Validate()
        {
            Console.WriteLine("PDF Validated..");

        }
        protected override void Save()
        {
            Console.WriteLine("PDF Saved..");

        }
    }
    public class DocX : Report
    {
        protected override void Parse()
        {
            Console.WriteLine("DocX Parsed..");
        }

        protected override void Validate()
        {
            Console.WriteLine("DocX Validated..");

        }
        protected override void Save()
        {
            Console.WriteLine("DocX Saved..");

        }
    }


    public class Doc1 : Report1
    {
        protected override void Parse()
        {
            Console.WriteLine("Doc1 Parsed..");
        }

        protected override void Validate()
        {
            Console.WriteLine("Doc1 Validated..");

        }
        protected override void Save()
        {
            Console.WriteLine("Doc1 Saved..");

        }

        protected override void ReValidate()
        {
            Console.WriteLine("Doc1 Re-Validated..");

        }
    }
}
