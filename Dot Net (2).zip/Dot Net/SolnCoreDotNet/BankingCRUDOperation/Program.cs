﻿

namespace BankingCRUDOperation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankSystem bs = new BankSystem();
            int ch;

            do
            {
                Console.WriteLine("1. Add Account");
                Console.WriteLine("2. Deposite Amount");
                Console.WriteLine("3. Withdraw Money");
                Console.WriteLine("4. Check Balance");
                Console.WriteLine("5. Show Account");
                Console.WriteLine("6. Exit");
                Console.WriteLine("Enter Your Choice");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Select Account type to create\n 1. Saving \n 2.Current");
                        int type = Convert.ToInt32(Console.ReadLine());

                        bs.createAcc(type);

                        break;

                    case 2:
                        Console.WriteLine("Enter the Amount to deposite");
                        int dep = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter acc no :");
                        int id = Convert.ToInt32(Console.ReadLine());

                        bs.Deposit(id, dep);

                        break;

                    case 3:

                        Console.WriteLine("Enter the Amount to withdraw");
                        int amt = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter acc no :");
                        id = Convert.ToInt32(Console.ReadLine());

                        bs.Withdraw(id, amt);

                        break;

                    case 4:
                        Console.WriteLine("Enter acc no :");
                        id = Convert.ToInt32(Console.ReadLine());
                        bs.CheckBalance(id);
                        break;

                    case 5:
                        Console.WriteLine("Enter acc no :");
                        id = Convert.ToInt32(Console.ReadLine());
                        bs.ShowAccDetails(id);
                        break;

                    case 6:
                        Console.WriteLine("Thank You");
                        break;

                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                }

            } while (ch != 6);
        }
    }

    public class Bank
    {
        public int Acno;
        public string Name;
        public double Bal;

        public Bank() { }

        public Bank(int acno, string name, double bal)
        {
            Acno = acno;
            Name = name;
            Bal = bal;
        }

        public int accno
        {
            get { return Acno; }
            set { Acno = value; }
        }

        public string name
        {
            get { return Name; }
            set { Name = value; }
        }

        public double Balance
        {
            get { return Bal; }
            set { Bal = value; }
        }



    }

    public class Saving : Bank
    {
        public double InterestRate;

        public Saving(int acno, string name, double bal, double interestRate)
            : base(acno, name, bal)
        {
            InterestRate = interestRate;
        }

        public double IRate
        {
            get { return InterestRate; }
            set { InterestRate = value; }
        }

        public void ApplyInterest()
        {
            double interest = Bal * InterestRate / 100;
            Bal += interest;
            Console.WriteLine($"Interest Applied: {interest}, New Balance: {Bal}");
        }
    }


    public class Current : Bank
    {
        public double OverdraftLimit;

        public Current(int acno, string name, double bal, double ol) : base(acno, name, bal)
        {
            OverdraftLimit = ol;
        }
        public double Olimit
        {
            get { return OverdraftLimit; }
            set { OverdraftLimit = value; }
        }

    }


    public class BankSystem
    {

        List<Bank> list = new List<Bank>();



        public void createAcc(int ch)
        {
            Console.WriteLine("Enter acc no :");
            int acc = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Name :");
            string name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter sal :");
            double sal = Convert.ToDouble(Console.ReadLine());

            Bank b = null;
            if (ch == 1)
            {
                Console.WriteLine("Enter InterestRate :");
                double intrate = Convert.ToDouble(Console.ReadLine());

                b = new Saving(acc, name, sal, intrate);
                list.Add(b);
            }
            else if (ch == 2)
            {
                Console.WriteLine("Enter OverdraftLimit :");
                double overlimit = Convert.ToDouble(Console.ReadLine());

                b = new Current(acc, name, sal, overlimit);
                list.Add(b);
            }
            else
            {
                Console.WriteLine("Invalid Choice");
            }

            Console.WriteLine("Account created successfully!");
        }




        public void Deposit(int id, double amount)
        {
            list.ForEach(b =>
            {
                if (b.Acno == id)
                {
                    b.Bal += amount;
                }
                Console.WriteLine($"Deposited: {amount}, New Balance: {b.Bal}");

            });


        }



        public void Withdraw(int id, double amount)
        {
            list.ForEach(b =>
            {
                if (b.Acno == id)
                {
                    if (amount > b.Bal)
                    {
                        Console.WriteLine("Insufficient balance!");
                    }
                    else
                    {
                        b.Bal -= amount;
                        Console.WriteLine($"Withdrawn: {amount}, Remaining Balance: {b.Bal}");
                    }
                }

            });

        }



        public void CheckBalance(int id)
        {
            list.ForEach(b =>
            {
                if (b.Acno == id)
                    Console.WriteLine($"Balance: {b.Bal}");
            });

        }


        public void ShowAccDetails(int id)
        {
            list.ForEach(b =>
            {
                if (b.Acno == id)
                {
                    Console.WriteLine($"Account: {b.Acno}, Holder: {b.Name}, Balance: {b.Bal}");
                }
            });

        }



    }
}
