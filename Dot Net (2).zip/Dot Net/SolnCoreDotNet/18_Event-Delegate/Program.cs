﻿using static System.Formats.Asn1.AsnWriter;

namespace _18_Event_Delegate
{
    public delegate void ResultHandler(int marks);
    internal class Program
    {
        static void Main(string[] args)
        {


            Student student = new Student();

      
            student._Pass += new ResultHandler(student.stud_Pass);
            student._Fail += new ResultHandler(student.stud_Fail);

            Console.WriteLine("Enter your Marks : ");
            student.Marks = Convert.ToInt32(Console.ReadLine());
           

        }

    }

    public class Student
    {
        public event ResultHandler _Pass; 

        public event ResultHandler _Fail; 

        private int _Marks;
        public int Marks
        {
            set
            {
                _Marks = value;
                if (_Marks > 40)
                {
                    _Pass(_Marks);
                }
                else
                {
                    _Fail.Invoke(_Marks); 
                }
            }
            get
            {
                return _Marks;
            }
        }
       
        public void stud_Pass(int mrks)
        {
            Console.WriteLine($"Congratulation !!! You Passed with {mrks} marks !!!");
        }
        public void stud_Fail(int mrks)
        {
            Console.WriteLine($"Congratulation !!! You Failed with {mrks} marks !!!");
        }
    }

}


















/*



import { useSelector , useDispatch } from "react-redux"
import { DecrementScore, IncrementScore } from "./Action/ScoreAction";

export function ScoreBoard(){

    const score = useSelector((state)=>{
        return state.ScoreReducer.score;
    })

    const dispatch= useDispatch();
const handleadd= () => {
    dispatch(IncrementScore());
}
    const handleminus=()=>{
        dispatch(DecrementScore());
    }
    return (
        < div >
            < h1 >{ score}</ h1 >
            < button onClick ={ handleadd}> +</ button >
            < button onClick ={ handleminus}> -</ button >
        </ div >
    )
}



*/